################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_bemfobserver.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_decoupling.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_extobserver.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fluxwkn.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_gain_calc.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_mtpa.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl2less.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl_damp_ctrl.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_control.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_gain_calc.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_spdobserver.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_transform.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_tuner_function.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_tuner_rls.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_vlimit.c \
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_volt_error_comp.c 

C_DEPS += \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_bemfobserver.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_decoupling.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_extobserver.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fluxwkn.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_gain_calc.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_mtpa.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl2less.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl_damp_ctrl.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_control.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_gain_calc.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_spdobserver.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_transform.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_tuner_function.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_tuner_rls.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_vlimit.d \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_volt_error_comp.d 

OBJS += \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_bemfobserver.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_decoupling.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_extobserver.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fluxwkn.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_gain_calc.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_mtpa.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl2less.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl_damp_ctrl.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_control.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_gain_calc.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_spdobserver.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_transform.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_tuner_function.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_tuner_rls.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_vlimit.o \
./ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_volt_error_comp.o 

SREC += \
RA6T2_MCB2_MCILV1_RAMP_E2S_V100.srec 

MAP += \
RA6T2_MCB2_MCILV1_RAMP_E2S_V100.map 


# Each subdirectory must supply rules for building sources it contributes
ra/fsp/lib/rm_motor_ctrllib/fpu32/%.o: ../ra/fsp/lib/rm_motor_ctrllib/fpu32/%.c
	$(file > $@.in,-mcpu=cortex-m33 -mthumb -mfloat-abi=hard -mfpu=fpv5-sp-d16 -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -gdwarf-4 -D_RENESAS_RA_ -D_RA_CORE=CM33 -D_RA_ORDINAL=1 -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/inc" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/inc/api" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/inc/instances" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/lib/rm_motor_ctrllib" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_pm_foc" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_sensor_bemf" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_control" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_hal_driver" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_tuner_pm" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_trajectory_linear" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra_gen" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/src" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/src/application" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/src/application/main" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/src/application/user_interface" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/src/application/user_interface/ics" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/src/application/tuner" -I"." -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include" -std=c99 -fstack-usage -fdump-rtl-pro_and_epilogue -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

