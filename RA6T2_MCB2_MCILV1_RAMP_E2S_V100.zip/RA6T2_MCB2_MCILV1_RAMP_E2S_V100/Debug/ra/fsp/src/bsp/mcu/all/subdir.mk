################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/fsp/src/bsp/mcu/all/bsp_clocks.c \
../ra/fsp/src/bsp/mcu/all/bsp_common.c \
../ra/fsp/src/bsp/mcu/all/bsp_delay.c \
../ra/fsp/src/bsp/mcu/all/bsp_group_irq.c \
../ra/fsp/src/bsp/mcu/all/bsp_guard.c \
../ra/fsp/src/bsp/mcu/all/bsp_io.c \
../ra/fsp/src/bsp/mcu/all/bsp_ipc.c \
../ra/fsp/src/bsp/mcu/all/bsp_irq.c \
../ra/fsp/src/bsp/mcu/all/bsp_macl.c \
../ra/fsp/src/bsp/mcu/all/bsp_ospi_b.c \
../ra/fsp/src/bsp/mcu/all/bsp_register_protection.c \
../ra/fsp/src/bsp/mcu/all/bsp_sbrk.c \
../ra/fsp/src/bsp/mcu/all/bsp_sdram.c \
../ra/fsp/src/bsp/mcu/all/bsp_security.c 

C_DEPS += \
./ra/fsp/src/bsp/mcu/all/bsp_clocks.d \
./ra/fsp/src/bsp/mcu/all/bsp_common.d \
./ra/fsp/src/bsp/mcu/all/bsp_delay.d \
./ra/fsp/src/bsp/mcu/all/bsp_group_irq.d \
./ra/fsp/src/bsp/mcu/all/bsp_guard.d \
./ra/fsp/src/bsp/mcu/all/bsp_io.d \
./ra/fsp/src/bsp/mcu/all/bsp_ipc.d \
./ra/fsp/src/bsp/mcu/all/bsp_irq.d \
./ra/fsp/src/bsp/mcu/all/bsp_macl.d \
./ra/fsp/src/bsp/mcu/all/bsp_ospi_b.d \
./ra/fsp/src/bsp/mcu/all/bsp_register_protection.d \
./ra/fsp/src/bsp/mcu/all/bsp_sbrk.d \
./ra/fsp/src/bsp/mcu/all/bsp_sdram.d \
./ra/fsp/src/bsp/mcu/all/bsp_security.d 

OBJS += \
./ra/fsp/src/bsp/mcu/all/bsp_clocks.o \
./ra/fsp/src/bsp/mcu/all/bsp_common.o \
./ra/fsp/src/bsp/mcu/all/bsp_delay.o \
./ra/fsp/src/bsp/mcu/all/bsp_group_irq.o \
./ra/fsp/src/bsp/mcu/all/bsp_guard.o \
./ra/fsp/src/bsp/mcu/all/bsp_io.o \
./ra/fsp/src/bsp/mcu/all/bsp_ipc.o \
./ra/fsp/src/bsp/mcu/all/bsp_irq.o \
./ra/fsp/src/bsp/mcu/all/bsp_macl.o \
./ra/fsp/src/bsp/mcu/all/bsp_ospi_b.o \
./ra/fsp/src/bsp/mcu/all/bsp_register_protection.o \
./ra/fsp/src/bsp/mcu/all/bsp_sbrk.o \
./ra/fsp/src/bsp/mcu/all/bsp_sdram.o \
./ra/fsp/src/bsp/mcu/all/bsp_security.o 

SREC += \
RA6T2_MCB2_MCILV1_RAMP_E2S_V100.srec 

MAP += \
RA6T2_MCB2_MCILV1_RAMP_E2S_V100.map 


# Each subdirectory must supply rules for building sources it contributes
ra/fsp/src/bsp/mcu/all/%.o: ../ra/fsp/src/bsp/mcu/all/%.c
	$(file > $@.in,-mcpu=cortex-m33 -mthumb -mfloat-abi=hard -mfpu=fpv5-sp-d16 -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -gdwarf-4 -D_RENESAS_RA_ -D_RA_CORE=CM33 -D_RA_ORDINAL=1 -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra_cfg/fsp_cfg/bsp" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/inc" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/inc/api" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/inc/instances" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/lib/rm_motor_ctrllib" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_pm_foc" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_sensor_bemf" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_control" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_hal_driver" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_tuner_pm" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/fsp/src/rm_motor_trajectory_linear" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra_gen" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/src" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/src/application" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/src/application/main" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/src/application/user_interface" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/src/application/user_interface/ics" -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/src/application/tuner" -I"." -I"C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_RAMP_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include" -std=c99 -fstack-usage -fdump-rtl-pro_and_epilogue -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

