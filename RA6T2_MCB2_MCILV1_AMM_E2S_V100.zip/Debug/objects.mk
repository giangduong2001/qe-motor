################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS := C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/src/application/user_interface/ics/ICS2_RA6T2.o

LIBS :=

