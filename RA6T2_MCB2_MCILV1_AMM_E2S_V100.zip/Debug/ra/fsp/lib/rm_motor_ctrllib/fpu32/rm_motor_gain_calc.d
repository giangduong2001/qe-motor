ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_gain_calc.o: \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_gain_calc.c \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_control.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_gain_calc.h
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_control.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_gain_calc.h:
