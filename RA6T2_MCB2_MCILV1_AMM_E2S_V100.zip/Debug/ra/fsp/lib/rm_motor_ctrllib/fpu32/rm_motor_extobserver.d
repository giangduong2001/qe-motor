ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_extobserver.o: \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_extobserver.c \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_extobserver.h
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_extobserver.h:
