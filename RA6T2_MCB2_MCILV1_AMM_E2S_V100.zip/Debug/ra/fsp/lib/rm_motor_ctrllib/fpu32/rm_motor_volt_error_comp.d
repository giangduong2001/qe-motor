ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_volt_error_comp.o: \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_volt_error_comp.c \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_volt_error_comp.h
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_volt_error_comp.h:
