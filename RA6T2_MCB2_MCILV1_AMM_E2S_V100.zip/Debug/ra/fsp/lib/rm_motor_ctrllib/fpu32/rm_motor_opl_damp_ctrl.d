ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl_damp_ctrl.o: \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl_damp_ctrl.c \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl_damp_ctrl.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.h
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl_damp_ctrl.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.h:
