ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_bemfobserver.o: \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_bemfobserver.c \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_bemfobserver.h
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_bemfobserver.h:
