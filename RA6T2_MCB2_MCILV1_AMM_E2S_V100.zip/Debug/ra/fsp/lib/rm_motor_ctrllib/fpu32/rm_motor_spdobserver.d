ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_spdobserver.o: \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_spdobserver.c \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_spdobserver.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.h
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_spdobserver.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.h:
