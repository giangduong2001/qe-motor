ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_control.o: \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_control.c \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_control.h
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_control.h:
