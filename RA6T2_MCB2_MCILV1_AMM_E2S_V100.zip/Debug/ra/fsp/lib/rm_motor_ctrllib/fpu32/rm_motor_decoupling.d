ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_decoupling.o: \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_decoupling.c \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_decoupling.h
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_decoupling.h:
