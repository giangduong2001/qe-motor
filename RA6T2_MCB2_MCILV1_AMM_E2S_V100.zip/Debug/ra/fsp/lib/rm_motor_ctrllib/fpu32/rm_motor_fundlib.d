ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.o: \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.c \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h:
