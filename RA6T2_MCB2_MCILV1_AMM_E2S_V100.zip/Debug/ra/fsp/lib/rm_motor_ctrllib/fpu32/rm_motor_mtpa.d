ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_mtpa.o: \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_mtpa.c \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_mtpa.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_mtpa.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h:
