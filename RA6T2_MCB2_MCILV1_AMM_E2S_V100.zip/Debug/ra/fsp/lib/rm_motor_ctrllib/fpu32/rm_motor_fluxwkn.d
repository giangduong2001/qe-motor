ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fluxwkn.o: \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fluxwkn.c \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fluxwkn.h \
 ../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fluxwkn.h:
../ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h:
