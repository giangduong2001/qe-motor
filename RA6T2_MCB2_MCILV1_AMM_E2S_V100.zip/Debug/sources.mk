################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ASM_UPPER_SRCS := 
O_SRCS := 
ELF_SRCS := 
SX_SRCS := 
LINKER_SCRIPT := 
JMP_UPPER_SRCS := 
P_UPPER_SRCS := 
SRC_SRCS := 
JMP_SRCS := 
FSY_UPPER_SRCS := 
PP_UPPER_SRCS := 
OBJ_UPPER_SRCS := 
ASM_SRCS := 
SX_UPPER_SRCS := 
O_UPPER_SRCS := 
S_UPPER_SRCS := 
ELF_UPPER_SRCS := 
C_UPPER_SRCS := 
OBJ_SRCS := 
S_SRCS := 
PP_SRCS := 
SRC_UPPER_SRCS := 
FSY_SRCS := 
P_SRCS := 
C_SRCS := 
JMP_DEPS := 
FSY_DEPS := 
C_UPPER_DEPS := 
SECONDARY_SIZE := 
SRC_UPPER_DEPS := 
P_UPPER_DEPS := 
S_DEPS := 
PP_UPPER_DEPS := 
P_DEPS := 
FSY_UPPER_DEPS := 
C_DEPS := 
SRC_DEPS := 
JMP_UPPER_DEPS := 
PP_DEPS := 
SX_DEPS := 
ASM_UPPER_DEPS := 
SX_UPPER_DEPS := 
OBJS := 
SECONDARY_FLASH := 
ASM_DEPS := 
SREC := 
S_UPPER_DEPS := 
MAP := 

# Every subdirectory with source files must be described here
SUBDIRS := \
ra/board/ra6t2_mck \
ra/fsp/lib/rm_motor_ctrllib/fpu32 \
ra/fsp/src/bsp/cmsis/Device/RENESAS/Source \
ra/fsp/src/bsp/mcu/all \
ra/fsp/src/bsp/mcu/ra6t2 \
ra/fsp/src/r_adc_b \
ra/fsp/src/r_agt \
ra/fsp/src/r_elc \
ra/fsp/src/r_gpt \
ra/fsp/src/r_gpt_three_phase \
ra/fsp/src/r_ioport \
ra/fsp/src/r_poeg \
ra/fsp/src/rm_motor_control \
ra/fsp/src/rm_motor_hal_driver \
ra/fsp/src/rm_motor_pm_foc \
ra/fsp/src/rm_motor_sensor_bemf \
ra/fsp/src/rm_motor_trajectory_linear \
ra/fsp/src/rm_motor_tuner_pm \
ra_gen \
script \
src/application/main \
src/application/tuner \
src/application/user_interface/ics \
src \

