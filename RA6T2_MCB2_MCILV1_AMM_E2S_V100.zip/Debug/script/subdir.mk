################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
LINKER_SCRIPT += \
../script/fsp.ld 

SREC += \
RA6T2_MCB2_MCILV1_AMM_E2S_V100.srec 

MAP += \
RA6T2_MCB2_MCILV1_AMM_E2S_V100.map 


# Each subdirectory must supply rules for building sources it contributes

