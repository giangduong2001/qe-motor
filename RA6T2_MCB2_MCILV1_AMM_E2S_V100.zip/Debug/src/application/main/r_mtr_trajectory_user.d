src/application/main/r_mtr_trajectory_user.o: \
 ../src/application/main/r_mtr_trajectory_user.c \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_gen/hal_data.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/bsp_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/fsp_common_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/fsp_version.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_gen/bsp_clock_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/ra6t2/bsp_override.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/ra6t2/bsp_elc.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/ra6t2/bsp_mcu_info.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/ra6t2/bsp_feature.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/ra6t2/bsp_peripheral.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/ra6t2/r_adc_device_types.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/board_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/board/ra6t2_mck/board.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/board/ra6t2_mck/board_init.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/board/ra6t2_mck/board_leds.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_gen/vector_data.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_exceptions.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/renesas.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/R7FA6T2BD.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm33.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_mpu.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_common.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/fsp_common_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_tfu.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_sdram.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_mmf.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_ipc.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_ospi_b.h \
 bsp_linker_info.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_register_protection.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_irq.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_io.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_group_irq.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_clocks.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_module_stop.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_security.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/fsp_features.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/fsp_common_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_delay.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_mcu_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_gen/common_data.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_elc.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/r_elc_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_elc_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/bsp_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_ioport.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_ioport_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/r_ioport_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_pin_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_poeg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_poeg_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/rm_motor_trajectory_linear.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_trajectory_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_agt.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/r_agt_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_timer_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/rm_motor_sensor_bemf.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_sensor_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/rm_motor_shared_pos_speed_data.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_mc_lib.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_common.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_volt_error_comp.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_bemfobserver.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_decoupling.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_extobserver.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fluxwkn.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_mtpa.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl_damp_ctrl.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl2less.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_control.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_gain_calc.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_gain_calc.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_spdobserver.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_transform.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_vlimit.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/rm_motor_shared_data_foc.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/rm_motor_shared_pos_speed_data.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_gpt.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_gpt_three_phase.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_three_phase_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_timer_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_adc_b.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_adc_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_elc_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_transfer_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/r_adc_b_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_transfer_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/rm_motor_hal_driver.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/rm_motor_shared_ccal_types.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/rm_motor_shared_ccal_macros.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/rm_motor_shared_ccal_types.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/rm_motor_hal_driver_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_hal_driver_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_adc_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_three_phase_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_tuner_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/rm_motor_tuner_pm.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/rm_motor_tuner_pm_cfg.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_tuner_lib.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_tuner_function.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_tuner_rls.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/rm_motor_pm_foc.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_algorithm_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_hal_driver_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_sensor_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/rm_motor_pm_foc/rm_motor_pm_foc_outer_fnc.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/rm_motor_control.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_speed_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_position_api.h \
 C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_algorithm_api.h
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_gen/hal_data.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/bsp_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/fsp_common_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/fsp_version.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_gen/bsp_clock_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/ra6t2/bsp_override.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/ra6t2/bsp_elc.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/ra6t2/bsp_mcu_info.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/ra6t2/bsp_feature.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/ra6t2/bsp_peripheral.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/ra6t2/r_adc_device_types.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/board_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/board/ra6t2_mck/board.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/board/ra6t2_mck/board_init.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/board/ra6t2_mck/board_leds.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_gen/vector_data.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_exceptions.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/renesas.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/R7FA6T2BD.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm33.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv8m_mpu.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/cmsis/Device/RENESAS/Include/system.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_common.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/fsp_common_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_tfu.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_sdram.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_mmf.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_ipc.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_ospi_b.h:
bsp_linker_info.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_register_protection.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_irq.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_io.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_group_irq.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_clocks.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_module_stop.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_security.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/fsp_features.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/fsp_common_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_compiler_support.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_delay.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/bsp/mcu/all/bsp_mcu_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_gen/common_data.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_elc.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/r_elc_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_elc_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/bsp_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_ioport.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_ioport_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/r_ioport_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/bsp/bsp_pin_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_poeg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_poeg_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/rm_motor_trajectory_linear.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_trajectory_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_agt.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/r_agt_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_timer_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/rm_motor_sensor_bemf.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_sensor_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/rm_motor_shared_pos_speed_data.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_mc_lib.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fundlib.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_common.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_volt_error_comp.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_bemfobserver.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_decoupling.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_extobserver.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_filter.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_fluxwkn.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_mtpa.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl_damp_ctrl.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_opl2less.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_control.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_gain_calc.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_pi_gain_calc.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_spdobserver.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_transform.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_vlimit.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/rm_motor_shared_data_foc.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/rm_motor_shared_pos_speed_data.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_gpt.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_gpt_three_phase.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_three_phase_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_timer_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/r_adc_b.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_adc_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_elc_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_transfer_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/r_adc_b_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_transfer_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/rm_motor_hal_driver.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/rm_motor_shared_ccal_types.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/rm_motor_shared_ccal_macros.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/rm_motor_shared_ccal_types.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/rm_motor_hal_driver_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_hal_driver_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_adc_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/r_three_phase_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_tuner_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/rm_motor_tuner_pm.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra_cfg/fsp_cfg/rm_motor_tuner_pm_cfg.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_tuner_lib.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_tuner_function.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/lib/rm_motor_ctrllib/fpu32/rm_motor_tuner_rls.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/rm_motor_pm_foc.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_algorithm_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_hal_driver_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_sensor_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/src/rm_motor_pm_foc/rm_motor_pm_foc_outer_fnc.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/instances/rm_motor_control.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_speed_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_position_api.h:
C:/Users/a5087695/e2_studio/workspace-2025-12_003/RA6T2_MCB2_MCILV1_AMM_E2S_V100/ra/fsp/inc/api/rm_motor_algorithm_api.h:
