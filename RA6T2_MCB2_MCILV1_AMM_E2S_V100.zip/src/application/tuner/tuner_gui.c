/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * File Name    : tuner_gui.c
 * Description  : GUI interface for RMW Tuner function
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * History : DD.MM.YYYY Version  Description
 *          : 09.12.2021 1.00
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Includes
 **********************************************************************************************************************/
#include <stdbool.h>
#include "hal_data.h"
#ifdef MOTOR_CONTROL_TUNER_ENABLED
 #include "tuner_gui.h"
 #include "rm_motor_tuner_api.h"
 #include "rm_motor_tuner_pm.h"

/***********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Typedef definitions
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * Exported global variables (to be accessed by other files)
 **********************************************************************************************************************/
extern const motor_instance_t          g_motor0_control;
extern motor_pm_foc_extended_cfg_t     g_user_motor_pm_foc_extended_cfg;
extern motor_hal_driver_extended_cfg_t g_user_motor_hal_driver_extended_cfg;
enum e_tuner_rmw_actions
{
    RMW_ACT_NONE               = 0,
    RMW_ACT_TUNER_START        = 1,
    RMW_ACT_TUNER_STOP         = 2,
    RMW_ACT_TUNER_RESET        = 3,
    RMW_ACT_APPLY_MOTOR_PARAMS = 4,
    RMW_ACT_TUNER_APPLY_PARAMS = 5
} gui_f4_rmw_action;                   /*< Action code from Renesas motor workbench, will be set 0 after non 0 value written */

uint8_t  gui_u1_use_init_r       = false;
uint8_t  gui_u1_use_init_ld      = false;
uint8_t  gui_u1_use_init_lq      = false;
uint8_t  gui_u1_use_init_ke      = false;
uint8_t  gui_u1_use_init_j       = false;
uint8_t  gui_u1_only_clear_error = false;
uint8_t  gui_u1_params_applied   = false;
uint16_t gui_u2_tuner_status;
float    gui_f4_init_r;
float    gui_f4_init_ld;
float    gui_f4_init_lq;
float    gui_f4_init_ke;
float    gui_f4_init_j;
float    gui_f4_r;
float    gui_f4_ld;
float    gui_f4_lq;
float    gui_f4_ke;
float    gui_f4_j;
float    gui_f4_d;
motor_tuner_volterr_lut_t gui_st_volterr_lut;
float gui_volterr_table_current[5];
float gui_volterr_table_volterr[5];

motor_tuner_volterr_lut_t g_st_volterr_lut;

uint16_t gui_u2_error_status;
uint8_t  gui_u1_tune_mode;
uint16_t gui_u2_measure_progress;
uint8_t  gui_u1_flag_tune_result;
uint8_t  gui_u1_flg_reset       = 0;
uint8_t  gui_u1_para_setting    = 0;
uint8_t  gui_u1_flag_tune_mode  = 1;
float    gui_f4_slide_parameter = 50.0f;
uint8_t  gui_u1_active_gui;
uint8_t  gui_u1_flg_1para_init = 0;
float    gui_f4_1para_speed_omega;

/* Variables directly accessible from RMW (read/write) */
float    gui_f4_tune_current_setting;       ///< The rated current
uint16_t gui_u2_tune_polepairs_setting;     ///< The number of pole pairs
float    gui_f4_tune_inertia_setting;       ///< The inertia identification range setting (0~1)
uint16_t gui_u2_tune_volterr_setting;       ///< The current step of voltage error identification
uint8_t  gui_u1_volterr_is_enabled;         ///< Whether enable the voltage error identification

extern float    com_f4_overspeed_limit_rpm; /* Over speed limit [rpm] */
extern uint16_t com_u2_mtr_pp;              /* Pole pairs */
extern float    com_f4_mtr_r;               /* Resistance [ohm] */
extern float    com_f4_mtr_ld;              /* D-axis inductance [H] */
extern float    com_f4_mtr_lq;              /* Q-axis inductance [H] */
extern float    com_f4_mtr_m;               /* Permanent magnetic flux [Wb] */
extern float    com_f4_mtr_j;               /* Rotor inertia [kgm^2] */
extern float    com_f4_ref_id;              /* Id reference when open loop [A] */
extern float    com_f4_current_omega;       /* Natural frequency for current loop [Hz] */
extern float    com_f4_current_zeta;        /* Damping ratio for current loop */
extern float    com_f4_speed_omega;         /* Natural frequency for speed loop [Hz] */
extern float    com_f4_speed_zeta;          /* Damping ratio for speed loop */
extern float    com_f4_e_obs_omega;         /* Natural frequency for BEMF observer [Hz] */
extern float    com_f4_e_obs_zeta;          /* Damping ratio for BEMF observer */
extern float    com_f4_pll_est_omega;       /* Natural frequency for rotor position Phase-Locked Loop [Hz] */
extern float    com_f4_pll_est_zeta;        /* Damping ratio for rotor position Phase-Locked Loop */
extern float    com_f4_ref_speed_rpm;
extern float    com_f4_max_speed_rpm;
extern float    com_f4_id_down_speed_rpm;
extern float    com_f4_id_up_speed_rpm;
extern float    com_f4_overcurrent_limit;                                                                         /* Over current limit */
extern float    com_f4_iq_limit;                                                                                  /* Q-axis current limit */
extern uint8_t  com_u1_enable_write;

/***********************************************************************************************************************
 * Macro definitions
 **********************************************************************************************************************/
 #define TUNER_PM_USER_CURRENT_OMEGA    (g_user_motor_pm_foc_extended_cfg.pm_inner_design_parameter->omega)       /* Natural frequency of current loop */
 #define TUNER_PM_USER_CURRENT_ZETA     (g_user_motor_pm_foc_extended_cfg.pm_inner_design_parameter->zeta)        /* Damping ratio of current loop */
 #define TUNER_PM_USER_SPEED_OMEGA      (g_user_motor_pm_foc_extended_cfg.pm_outer_design_parameter->speed_omega) /* Natural frequency of speed loop */
 #define TUNER_PM_USER_SPEED_ZETA       (1.0f)                                                                    /* Damping ratio of speed loop */
 #define TUNER_PM_USER_E_OBS_OMEGA      (g_user_motor_estimate_extended_cfg.e_obs_omega)                          /* Natural frequency of BEMF observer */
 #define TUNER_PM_USER_E_OBS_ZETA       (g_user_motor_estimate_extended_cfg.e_obs_zeta)                           /* Damping ratio of BEMF observer */
 #define TUNER_PM_USER_PLL_EST_OMEGA    (g_user_motor_estimate_extended_cfg.pll_est_omega)                        /* Natural frequency of PLL Speed estimate loop */
 #define TUNER_PM_USER_PLL_EST_ZETA     (g_user_motor_estimate_extended_cfg.pll_est_zeta)                         /* Damping ratio of PLL Speed estimate loop */
 #define TUNER_PM_USER_INPUT_V          (g_user_motor_hal_driver_extended_cfg.mod_param.v_dc)                     /* Damping ratio of PLL Speed estimate loop */

/***********************************************************************************************************************
 * Private global variables and functions
 **********************************************************************************************************************/
static uint8_t gs_is_tuner_running = false;

static void     tuner_act_ready(void);
static void     tuner_act_measure(void);
static void     tuner_act_error(void);
static void     tuner_act_completed(void);
static void     tuner_save_identified_params(void);
static void     tuner_reset(void);
static void     tuner_rmw_act_start(void);
static uint16_t tuner_rmw_get_progress(void);
static void     tuner_gui_apply_result_by_rmw(void);
static void     tuner_rmw_apply_reset(void);

const motor_tuner_instance_t * p_user_tuner;
motor_tuner_cfg_t              g_user_motor_tuner_cfg;
motor_tuner_pm_extend_cfg_t    g_user_motor_tuner_pm_extend_cfg;

/***********************************************************************************************************************
 * Function Name : R_TUNER_InitGUI
 * Description   :
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
void R_TUNER_InitGUI (void)
{
    motor_pm_foc_extended_cfg_t const * p_ext = &g_user_motor_pm_foc_extended_cfg;

    gui_u1_volterr_is_enabled = 0;

    /* Configurations now generated in hal_data.c as constants */
    /* Create a deep clone of configuration and use it for opening tuner, so tuner will use them as runtime configuration */
    p_user_tuner = &g_motor0_tuner_pm;
    g_user_motor_tuner_pm_extend_cfg = g_motor0_tuner_pm_extend_cfg;
    g_user_motor_tuner_cfg           = g_motor0_tuner_pm_cfg;
    g_user_motor_tuner_cfg.p_extend  = &g_user_motor_tuner_pm_extend_cfg;

    p_user_tuner->p_api->open(p_user_tuner->p_ctrl, &g_user_motor_tuner_cfg);

    g_st_volterr_lut.ref_voltage = p_ext->data.comp_vdc_ref;
    for (uint8_t i = 0; i < TUNER_VOLTAGE_ERROR_LUT_SIZE; i++)
    {
        g_st_volterr_lut.current_breakpoints[i] = p_ext->data.comp_i[i];
        g_st_volterr_lut.volterr_table[i]       = p_ext->data.comp_v[i];
    }

    p_user_tuner->p_api->voltageErrorLutSet(p_user_tuner->p_ctrl, &g_st_volterr_lut);
}

/***********************************************************************************************************************
 * Function Name : R_TUNER_MainLoop
 * Description   :
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
void R_TUNER_MainLoop (void)
{
    /* Start Button */
    if (gui_u1_tune_mode == TUNER_PM_USER_TUNE_MODE_START)
    {
        p_user_tuner->p_api->open(p_user_tuner->p_ctrl, &g_user_motor_tuner_cfg);
        p_user_tuner->p_api->voltageErrorLutSet(p_user_tuner->p_ctrl, &g_st_volterr_lut);

        gui_f4_rmw_action = RMW_ACT_TUNER_START;
        gui_u1_tune_mode  = TUNER_PM_USER_TUNE_MODE_MAX;
    }

    /* Reset Button */
    if (gui_u2_tuner_status == MOTOR_TUNER_STATUS_RESET)
    {
        gui_f4_rmw_action = RMW_ACT_TUNER_RESET;
        tuner_rmw_apply_reset();
    }

    /* Stop Button */
    if (gui_u2_error_status == TUNER_PM_USER_ERROR_ASSERT_FAIL)
    {
        p_user_tuner->p_api->abort(p_user_tuner->p_ctrl, TUNER_PM_USER_ERROR_STOP_BUTTON);
    }

    motor_tuner_status_t tuner_status;
    p_user_tuner->p_api->statusGet(p_user_tuner->p_ctrl, &tuner_status);

    /* Note: The GUI checks the COMPLETED status by gui_u2_tuner_status = 0, ,
     * so the gui_u2_tuner_status should be synchrounized before executing actions. */
    gui_u2_tuner_status = (tuner_status == MOTOR_TUNER_STATUS_COMPLETED) ? 0 : ((uint16_t) tuner_status);

    switch (tuner_status)
    {
        case MOTOR_TUNER_STATUS_READY:
        {
            gui_u2_measure_progress = 0;
            tuner_act_ready();
            break;
        }

        case MOTOR_TUNER_STATUS_RUNNING:
        {
            tuner_act_measure();
            gui_u2_measure_progress = tuner_rmw_get_progress();
            break;
        }

        case MOTOR_TUNER_STATUS_ERROR:
        {
            p_user_tuner->p_api->errorGet(p_user_tuner->p_ctrl, &gui_u2_error_status);
            tuner_act_error();
            break;
        }

        case MOTOR_TUNER_STATUS_COMPLETED:
        {
            tuner_act_completed();
            break;
        }

        default:
        {
            /* Do nothing */
        }
    }

    /* Clear command/action to make sure the command is only executed once */
    gui_f4_rmw_action = RMW_ACT_NONE;
}

/***********************************************************************************************************************
 * Function Name : R_TUNER_IsRunning
 * Description   :
 * Arguments     : None
 * Return Value  :
 ***********************************************************************************************************************/
uint8_t R_TUNER_IsRunning (void)
{
    return gs_is_tuner_running;
}

/***********************************************************************************************************************
 * Function Name : R_TUNER_SetTuneResult
 * Description   : Set gui_u1_flag_tune_result
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
void R_TUNER_SetTuneResult (void)
{
    gui_u1_flag_tune_result = TUNER_PM_USER_FLG_SET;
}

/***********************************************************************************************************************
 * Function Name : R_TUNER_GetFlagReset
 * Description   : Get gui_u1_flg_reset
 * Arguments     : None
 * Return Value  :
 ***********************************************************************************************************************/
uint8_t R_TUNER_GetFlagReset (void)
{
    return gui_u1_flg_reset;
}

/***********************************************************************************************************************
 * Function Name : R_TUNER_SetFlagReset
 * Description   : Set gui_u1_flg_reset
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
void R_TUNER_SetFlagReset (uint8_t num)
{
    gui_u1_flg_reset = num;
}

/***********************************************************************************************************************
 * Function Name : tuner_act_ready
 * Description   :
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void tuner_act_ready (void)
{
    switch (gui_f4_rmw_action)
    {
        case RMW_ACT_TUNER_START:
        {
            tuner_rmw_act_start();
            gs_is_tuner_running = true;
            break;
        }

        default:
        {
            gs_is_tuner_running = false;
        }
    }
}

/***********************************************************************************************************************
 * Function Name : tuner_act_measure
 * Description   :
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void tuner_act_measure (void)
{
    switch (gui_f4_rmw_action)
    {
        case RMW_ACT_TUNER_STOP:
        {
            p_user_tuner->p_api->stop(p_user_tuner->p_ctrl);
            gs_is_tuner_running = false;
            break;
        }

        default:
        {
            /* Do nothing */
        }
    }
}

/***********************************************************************************************************************
 * Function Name : tuner_act_error
 * Description   :
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void tuner_act_error (void)
{
    switch (gui_f4_rmw_action)
    {
        case RMW_ACT_TUNER_RESET:
        {
            tuner_reset();
            gs_is_tuner_running = true;
            break;
        }

        default:
        {
            gs_is_tuner_running = false;
        }
    }
}

/***********************************************************************************************************************
 * Function Name : tuner_act_completed
 * Description   :
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void tuner_act_completed (void)
{
    /* Store identified parameters,
     * variables inside the tuner may be reset next */
    if (gui_u1_params_applied == false)
    {
        tuner_save_identified_params();
        tuner_gui_apply_result_by_rmw();
        gui_u1_params_applied = true;
    }

    switch (gui_f4_rmw_action)
    {
        case RMW_ACT_TUNER_RESET:
        {
            tuner_reset();
            gs_is_tuner_running = true;
            break;
        }

        case RMW_ACT_TUNER_START:      /* Start command is also available in COMPLETED state */
        {
            tuner_rmw_act_start();
            gs_is_tuner_running = true;
            break;
        }

        case RMW_ACT_TUNER_APPLY_PARAMS:
        {
            tuner_gui_apply_result_by_rmw();
            break;
        }

        default:
        {
            gs_is_tuner_running = false;
            gui_u2_tuner_status = MOTOR_TUNER_STATUS_READY;
            gui_u1_tune_mode    = TUNER_PM_USER_TUNE_MODE_DEFAULT;
        }
    }
}

/***********************************************************************************************************************
 * Function Name : tuner_reset
 * Description   :
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void tuner_reset (void)
{
    if (false == gui_u1_only_clear_error)
    {
        gui_f4_r  = 0.0f;
        gui_f4_ld = 0.0f;
        gui_f4_lq = 0.0f;
        gui_f4_ke = 0.0f;
        gui_f4_j  = 0.0f;
        gui_f4_d  = 0.0f;
    }

    p_user_tuner->p_api->reset(p_user_tuner->p_ctrl);
}

/***********************************************************************************************************************
 * Function Name : tuner_save_identified_params
 * Description   :
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void tuner_save_identified_params (void)
{
    p_user_tuner->p_api->identifiedParamGet(p_user_tuner->p_ctrl, MOTOR_TUNER_PARAM_TYPE_PMSM_R, &gui_f4_r);
    p_user_tuner->p_api->identifiedParamGet(p_user_tuner->p_ctrl, MOTOR_TUNER_PARAM_TYPE_PMSM_LD, &gui_f4_ld);
    p_user_tuner->p_api->identifiedParamGet(p_user_tuner->p_ctrl, MOTOR_TUNER_PARAM_TYPE_PMSM_LQ, &gui_f4_lq);
    p_user_tuner->p_api->identifiedParamGet(p_user_tuner->p_ctrl, MOTOR_TUNER_PARAM_TYPE_PMSM_KE, &gui_f4_ke);
    p_user_tuner->p_api->identifiedParamGet(p_user_tuner->p_ctrl, MOTOR_TUNER_PARAM_TYPE_INERTIA, &gui_f4_j);
    p_user_tuner->p_api->identifiedParamGet(p_user_tuner->p_ctrl, MOTOR_TUNER_PARAM_TYPE_VISCOUS_FRICTION, &gui_f4_d);
    p_user_tuner->p_api->identifiedVoltageErrorGet(p_user_tuner->p_ctrl, &gui_st_volterr_lut, NULL);
}

/***********************************************************************************************************************
 * Function Name : tuner_rmw_act_start
 * Description   :
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void tuner_rmw_act_start (void)
{
    /* Identification configuration can be done by writing variables with gui_ prefix */

    /* gui_u1_use_init prefix variables shows whether the initial parameter told by GUI should be used */
    p_user_tuner->p_api->knownParamSet(p_user_tuner->p_ctrl,
                                       MOTOR_TUNER_PARAM_TYPE_PMSM_R,
                                       gui_u1_use_init_r ? gui_f4_init_r : 0.0f);
    p_user_tuner->p_api->knownParamSet(p_user_tuner->p_ctrl,
                                       MOTOR_TUNER_PARAM_TYPE_PMSM_LD,
                                       gui_u1_use_init_ld ? gui_f4_init_ld : 0.0f);
    p_user_tuner->p_api->knownParamSet(p_user_tuner->p_ctrl,
                                       MOTOR_TUNER_PARAM_TYPE_PMSM_LQ,
                                       gui_u1_use_init_lq ? gui_f4_init_lq : 0.0f);
    p_user_tuner->p_api->knownParamSet(p_user_tuner->p_ctrl,
                                       MOTOR_TUNER_PARAM_TYPE_PMSM_KE,
                                       gui_u1_use_init_ke ? gui_f4_init_ke : 0.0f);
    p_user_tuner->p_api->knownParamSet(p_user_tuner->p_ctrl,
                                       MOTOR_TUNER_PARAM_TYPE_INERTIA,
                                       gui_u1_use_init_j ? gui_f4_init_j : 0.0f);
    p_user_tuner->p_api->knownParamSet(p_user_tuner->p_ctrl,
                                       MOTOR_TUNER_PARAM_TYPE_POLE_PAIRS,
                                       gui_u2_tune_polepairs_setting);

    p_user_tuner->p_api->knownParamSet(p_user_tuner->p_ctrl,
                                       MOTOR_TUNER_PARAM_TYPE_RATED_CURRENT,
                                       gui_f4_tune_current_setting);

    p_user_tuner->p_api->start(p_user_tuner->p_ctrl);
    gui_u1_params_applied = false;
}

/***********************************************************************************************************************
 * Function Name : tuner_rmw_get_progress
 * Description   :
 * Arguments     : None
 * Return Value  :
 ***********************************************************************************************************************/
static uint16_t tuner_rmw_get_progress (void)
{
    float    progress;
    uint16_t ret;

    p_user_tuner->p_api->progressGet(p_user_tuner->p_ctrl, &progress);
    ret = 0;
    if (progress > TUNER_PM_USER_PROGRESS_R)
    {
        ret = TUNER_PM_USER_MEASURE_PROGRESS_R;
    }

    if (progress > TUNER_PM_USER_PROGRESS_L)
    {
        ret = TUNER_PM_USER_MEASURE_PROGRESS_L;
    }

    if (progress > TUNER_PM_USER_PROGRESS_KE)
    {
        ret = TUNER_PM_USER_MEASURE_PROGRESS_KE;
    }

    if (progress > TUNER_PM_USER_PROGRESS_JD)
    {
        ret = TUNER_PM_USER_MEASURE_PROGRESS_JD;
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name : tuner_gui_apply_result_by_rmw
 * Description   :
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void tuner_gui_apply_result_by_rmw (void)
{
    motor_tuner_pm_extend_cfg_t * p_extend = (motor_tuner_pm_extend_cfg_t *) g_user_motor_tuner_cfg.p_extend;
    float ia_max;
    float va_max;

    com_f4_overcurrent_limit = gui_f4_tune_current_setting;
    com_u2_mtr_pp            = gui_u2_tune_polepairs_setting;
    ia_max        = gui_f4_tune_current_setting * (TUNER_PM_USER_SQRT_3 / TUNER_PM_USER_SQRT_2);
    va_max        = TUNER_PM_USER_INPUT_V * (TUNER_PM_USER_SQRT_3 / TUNER_PM_USER_SQRT_2) * 0.5f * 0.9f;
    com_f4_mtr_r  = gui_f4_r;
    com_f4_mtr_ld = gui_f4_ld;
    com_f4_mtr_lq = gui_f4_lq;
    com_f4_mtr_m  = gui_f4_ke;
    com_f4_mtr_j  = gui_f4_j;

    com_f4_max_speed_rpm = (va_max / gui_f4_ke) / (float) com_u2_mtr_pp * (60.0f / TUNER_PM_USER_TWOPI);

    /* Leave 50% margin from maximum speed for detecting overspeed error */
    com_f4_overspeed_limit_rpm = com_f4_max_speed_rpm * 1.5f;

    com_f4_ref_id            = ia_max * p_extend->base_foc_cfg.id_ref_coef;
    com_f4_id_down_speed_rpm = com_f4_max_speed_rpm * p_extend->base_foc_cfg.ol2cl_speed_th_coef;
    com_f4_id_up_speed_rpm   = com_f4_max_speed_rpm * p_extend->base_foc_cfg.cl2ol_speed_th_coef;
    com_f4_ref_speed_rpm     = com_f4_max_speed_rpm * 0.5f; /* Use 50% maximum speed as initial speed command */
    com_f4_iq_limit          = com_f4_overcurrent_limit;

    com_u1_enable_write ^= 1;
}

/***********************************************************************************************************************
 * Function Name : R_TUNER_OneParameterHandler
 * Description   :
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
void R_TUNER_OneParameterHandler (void)
{
    uint8_t temp;

    /* for 1 parameter */
    temp = gui_u1_active_gui & 0x04;
    if ((0x04 == temp) && (TUNER_PM_USER_1_PARAMETER_SET == gui_u1_flag_tune_mode))
    {
        if (gui_u1_flg_1para_init != TUNER_PM_USER_1_PARAMETER_SET)
        {
            gui_f4_1para_speed_omega = TUNER_PM_USER_SPEED_OMEGA;
            gui_u1_flg_1para_init    = TUNER_PM_USER_1_PARAMETER_SET;
        }

        if (gui_f4_slide_parameter > 100.0f)
        {
            gui_f4_slide_parameter = 100.0f;
        }
        else if (gui_f4_slide_parameter < 0)
        {
            gui_f4_slide_parameter = 0.0f;
        }

        com_f4_current_omega = g_user_motor_tuner_pm_extend_cfg.base_foc_cfg.current_omega_hz;
        com_f4_current_zeta  = g_user_motor_tuner_pm_extend_cfg.base_foc_cfg.current_zeta;
        com_f4_speed_omega   = 1.0f + ((gui_f4_1para_speed_omega - 1.0f) * 2) * gui_f4_slide_parameter / 100.0f;
        com_f4_speed_zeta    = TUNER_PM_USER_SPEED_ZETA;
        com_f4_e_obs_omega   = g_user_motor_tuner_pm_extend_cfg.base_foc_cfg.e_obs_omega_hz;
        com_f4_e_obs_zeta    = g_user_motor_tuner_pm_extend_cfg.base_foc_cfg.e_obs_zeta;
        com_f4_pll_est_omega = g_user_motor_tuner_pm_extend_cfg.base_foc_cfg.pll_est_omega_hz;
        com_f4_pll_est_zeta  = g_user_motor_tuner_pm_extend_cfg.base_foc_cfg.pll_est_zeta;
    }
}

/***********************************************************************************************************************
 * Function Name : R_TUNER_ICSHandler
 * Description   : ICS interrupt handler
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
void R_TUNER_ICSHandler (void)
{
    if (gui_u1_flg_reset == TUNER_PM_USER_RESET_MODE1)
    {
        g_motor0_control.p_api->reset(g_motor0_control.p_ctrl); // Reset via Motor API
        gui_u1_flg_reset = TUNER_PM_USER_RESET_MODE2;
    }
}

/***********************************************************************************************************************
 * Function Name : tuner_rmw_apply_reset
 * Description   : Reset motor control
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void tuner_rmw_apply_reset (void)
{
    tuner_reset();
    g_motor0_control.p_api->reset(g_motor0_control.p_ctrl); // Reset via Motor API
}

#endif // MOTOR_CONTROL_TUNER_ENABLED
