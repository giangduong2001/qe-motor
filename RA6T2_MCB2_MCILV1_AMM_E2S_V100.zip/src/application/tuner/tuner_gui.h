/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2025 Renesas Electronics Corporation. All rights reserved.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name    : tuner_gui.h
 * Description  : GUI interface for RMW Tuner function
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version  Description
*          : 09.12.2025 1.00
 **********************************************************************************************************************/

/***********************************************************************************************************************
 Includes
 **********************************************************************************************************************/

#ifndef TUNER_GUI_H
#define TUNER_GUI_H
#include <stdint.h>

/***********************************************************************************************************************
 Macro definitions
 **********************************************************************************************************************/
#define TUNER_PM_USER_1_PARAMETER_SET         (1)
#define TUNER_PM_USER_SQRT_3                  (1.7320508f)
#define TUNER_PM_USER_SQRT_2                  (1.41421356f)
#define TUNER_PM_USER_TWOPI                   (3.14159265358979F * 2.0F)

#define TUNER_PM_USER_RESET_MODE0        (0)
#define TUNER_PM_USER_RESET_MODE1        (1)
#define TUNER_PM_USER_RESET_MODE2        (2)

#define TUNER_PM_USER_STATUS_READY            (0)
#define TUNER_PM_USER_STATUS_MEASURE          (1)
#define TUNER_PM_USER_STATUS_ERROR            (2)
#define TUNER_PM_USER_STATUS_RESET            (3)


// #define TUNER_PM_USER_PWM_TICK_PER_IRQ        (TUNER_PM_USER_INT_DECIMATION + 1)

#define TUNER_PM_USER_TUNE_MODE_DEFAULT       (0)
#define TUNER_PM_USER_TUNE_MODE_START         (4)
#define TUNER_PM_USER_TUNE_MODE_MAX           (255)

#define TUNER_PM_USER_ERROR_STOP_BUTTON       (254)
#define TUNER_PM_USER_ERROR_ASSERT_FAIL       (255)

#define TUNER_PM_USER_PROGRESS_R              (0.55f)
#define TUNER_PM_USER_PROGRESS_L              (0.64f)
#define TUNER_PM_USER_PROGRESS_KE             (0.69f)
#define TUNER_PM_USER_PROGRESS_JD             (0.75f)

#define TUNER_PM_USER_MEASURE_PROGRESS_R      (1)
#define TUNER_PM_USER_MEASURE_PROGRESS_L      (2)
#define TUNER_PM_USER_MEASURE_PROGRESS_KE     (3)
#define TUNER_PM_USER_MEASURE_PROGRESS_JD     (4)

#define TUNER_PM_USER_TUNE_INERTIA_SETTING    (0.0f)
#define TUNER_PM_USER_TUNE_VOLTERR_SETTING    (2)

#define TUNER_PM_USER_FLG_SET                 (1)

/***********************************************************************************************************************
 Typedef definitions
 **********************************************************************************************************************/

/***********************************************************************************************************************
 Exported global variables
 **********************************************************************************************************************/

/***********************************************************************************************************************
 Exported global functions (to be accessed by other files)
 **********************************************************************************************************************/
void    R_TUNER_InitGUI (void);
void    R_TUNER_MainLoop (void);
uint8_t R_TUNER_IsRunning(void);
void    R_TUNER_SetTuneResult(void);
uint8_t R_TUNER_GetFlagReset(void);
void    R_TUNER_SetFlagReset(uint8_t);
void    R_TUNER_ICSHandler(void);
void    R_TUNER_OneParameterHandler(void);

#endif /* TUNER_GUI_H */


