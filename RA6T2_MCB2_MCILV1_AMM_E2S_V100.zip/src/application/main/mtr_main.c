/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2023 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

/***********************************************************************************************************************
 * File Name   : mtr_main.c
 * Description : The main function and the processes of motor control application layer
 ***********************************************************************************************************************/

/**********************************************************************************************************************
 * History : DD.MM.YYYY Version
 *         : 23.05.2023 1.00
 ***********************************************************************************************************************/

/***********************************************************************************************************************
 * Includes <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include <stdint.h>
#include "mtr_main.h"
#include "hal_data.h"
#include "ics2_RA6T2.h"
#include "r_mtr_ics.h"
#ifdef MOTOR_CONTROL_TUNER_ENABLED
 #include "tuner_gui.h"
#endif

#define     CONF_MOTOR_TYPE        ("Brushless DC Motor")
#define     CONF_CONTROL           ("Sensorless vector control (Speed control)")
#define     CONF_INVERTER          ("MCI-LV-1")
#define     CONF_MOTOR_TYPE_LEN    (18)
#define     CONF_CONTROL_LEN       (41)
#define     CONF_INVERTER_LEN      (8)

/***********************************************************************************************************************
 * Global variables
 ***********************************************************************************************************************/
float                       g_f4_speed_ref = 0.0F;
uint8_t                     g_u1_motor_status;  /* Motor status */
uint8_t                     com_u1_sw_userif;   /* User interface switch */
uint8_t                     g_u1_sw_userif;     /* User interface switch */
uint8_t                     com_u1_mode_system; /* System mode */
uint8_t                     g_u1_mode_system;   /* System mode */
uint16_t                    g_u2_max_speed_rpm;
uint8_t                     g_u1_stop_req;
uint16_t                    g_u2_chk_error;
uint16_t                    g_u2_vr1_ad;
uint16_t                    g_u2_conf_hw;
uint16_t                    g_u2_conf_sw;
uint16_t                    g_u2_conf_tool;
uint8_t                     g_u1_conf_motor_type_len;
uint8_t                     g_u1_conf_control_len;
uint8_t                     g_u1_conf_inverter_len;
uint8_t                     g_u1_conf_motor_type[CONF_MOTOR_TYPE_LEN];
uint8_t                     g_u1_conf_control[CONF_CONTROL_LEN];
uint8_t                     g_u1_conf_inverter[CONF_INVERTER_LEN];
uint8_t                     g_u1_reset_req; /* Reset request flag */
uint8_t                     g_u1_sw_cnt;    /* Counter to remove chattering */
motor_cfg_t                 g_user_motor_cfg;
motor_algorithm_cfg_t       g_user_motor_pm_foc_cfg;
motor_pm_foc_extended_cfg_t g_user_motor_pm_foc_extended_cfg;
motor_sensor_cfg_t          g_user_motor_sensor_cfg;
motor_sensor_cfg_t          g_user_motor_sensor_cfg_2nd;

#if(MOTOR_SENSOR_1 == 1)
motor_sensor_bemf_extended_cfg_t g_user_motor_estimate_extended_cfg;
#endif
#if(MOTOR_SENSOR_1 == 2)
motor_sensor_hall_extended_cfg_t g_user_motor_sensor_hall_extended_cfg;
#endif
extern const motor_instance_t   g_motor0_control;
motor_hal_driver_cfg_t          g_user_motor_hal_driver_cfg;
motor_hal_driver_extended_cfg_t g_user_motor_hal_driver_extended_cfg;
motor_parameter_ramp_t          g_user_motor_current_motor_parameter;
motor_design_param_t            g_user_motor_current_design_parameter;

/***********************************************************************************************************************
 * Private functions
 ***********************************************************************************************************************/
static void     motor_fsp_init(void);
static void     mtr_board_led_control(uint8_t u1_motor_status);
static uint8_t  mtr_remove_sw_chattering(uint8_t u1_sw, uint8_t u1_on_off);
static void     board_ui(void);        /* Board user interface */
static void     ics_ui(void);          /* ICS (Analyzer) user interface */
static void     software_init(void);   /* Software initialize */
static uint16_t get_vr1(void);
static uint8_t  get_sw1(void);
static uint8_t  get_sw2(void);
static void     led1_on(void);
static void     led2_on(void);
static void     led3_on(void);
static void     led1_off(void);
static void     led2_off(void);
static void     led3_off(void);

#ifdef MOTOR_CONTROL_TUNER_ENABLED
uint16_t g_u2_tune_mode     = 0;
uint16_t g_u2_tune_mode_pre = 0;

void rm_motor_inner_loop_callback(adc_callback_args_t * p_args);
void rm_motor_outer_loop_callback(timer_callback_args_t * p_args);

#endif

#ifdef MOTOR_CONTROL_TRAJECTORY_ENABLED
extern void rm_motor_trajectory_init(void);
#endif

/***********************************************************************************************************************
 * Function Name : mtr_init
 * Description   : Initialization for Motor Control
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
void mtr_init (void)
{
    int     i;
    uint8_t u1_conf_motor_type[] = CONF_MOTOR_TYPE;
    uint8_t u1_conf_control[]    = CONF_CONTROL;
    uint8_t u1_conf_inverter[]   = CONF_INVERTER;
    g_u1_conf_motor_type_len = CONF_MOTOR_TYPE_LEN;
    g_u1_conf_control_len    = CONF_CONTROL_LEN;
    g_u1_conf_inverter_len   = CONF_INVERTER_LEN;
    for (i = 0; i < g_u1_conf_motor_type_len; i++)
    {
        g_u1_conf_motor_type[i] = u1_conf_motor_type[i];
    }

    for (i = 0; i < g_u1_conf_control_len; i++)
    {
        g_u1_conf_control[i] = u1_conf_control[i];
    }

    for (i = 0; i < g_u1_conf_inverter_len; i++)
    {
        g_u1_conf_inverter[i] = u1_conf_inverter[i];
    }

    g_u2_conf_hw = 0x0008;             /* 0000000000001000b */
#ifdef MOTOR_CONTROL_TUNER_ENABLED
    g_u2_conf_sw   = 0x4000;           /* 0100000000000000b */
    g_u2_conf_tool = 0x0600;           /* 0000011000000000b */
#else
    g_u2_conf_sw   = 0x0000;           /* 0000000000000000b */
    g_u2_conf_tool = 0x0300;           /* 0000011000000000b */
#endif

    motor_fsp_init();
    software_init();                   /* Initialize private global variables */

    ics2_init(ICS_SCI9_PD05_PD06, ICS_BRR, ICS_INT_MODE);

    /* Execute reset event */
    g_motor0_control.p_api->reset(g_motor0_control.p_ctrl);

#ifdef MOTOR_CONTROL_TRAJECTORY_ENABLED

    /* Initialize trajectory module with proper configuration */
    rm_motor_trajectory_init();
#endif
#ifdef MOTOR_CONTROL_TUNER_ENABLED
    R_TUNER_InitGUI();
#endif
}                                      /* End of function mtr_init() */

/***********************************************************************************************************************
 * Function Name : mtr_main
 * Description   : Main routine for Motor Control
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
void mtr_main (void)
{
    /*** select user interfaces ***/
    if (g_u1_sw_userif != com_u1_sw_userif)
    {
        g_u1_sw_userif = com_u1_sw_userif;
        if (ICS_UI == g_u1_sw_userif)
        {
            g_u1_mode_system = g_u1_motor_status;
        }
    }

    if (BOARD_UI == g_u1_sw_userif)
    {
        board_ui();                    /* User interface control routine */
    }
    else if (ICS_UI == g_u1_sw_userif)
    {
        ics_ui();                      /* User interface using ICS */
    }
    else
    {
        /* Do Nothing */
    }

#ifdef MOTOR_CONTROL_TUNER_ENABLED
    R_TUNER_MainLoop();
#endif
}                                      /* End of function mtr_main() */

/***********************************************************************************************************************
 * Function Name : board_ui
 * Description   : User interface using board UI
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void board_ui (void)
{
    uint8_t u1_temp_sw_signal;

    /*======================*/
    /*     Mode control     */
    /*======================*/

    /* Get status of motor control system */
    g_motor0_control.p_api->statusGet(g_motor0_control.p_ctrl, &g_u1_motor_status);
    switch (g_u1_motor_status)
    {
        case MOTOR_CONTROL_STATUS_STOP:
        {
            u1_temp_sw_signal = get_sw1();

            /* Check SW1 */
            if ((MTR_FLG_SET == mtr_remove_sw_chattering(u1_temp_sw_signal, SW1_ON)) && (MTR_FLG_SET != g_u1_stop_req))
            {
                g_motor0_control.p_api->run(g_motor0_control.p_ctrl);
            }

            break;
        }

        case MOTOR_CONTROL_STATUS_RUN:
        {
            u1_temp_sw_signal = get_sw1();

            /* Check SW1 */
            if ((MTR_FLG_SET == mtr_remove_sw_chattering(u1_temp_sw_signal, SW1_OFF)) || (MTR_FLG_CLR != g_u1_stop_req))
            {
                g_motor0_control.p_api->stop(g_motor0_control.p_ctrl);
            }

            break;
        }

        case MOTOR_CONTROL_STATUS_ERROR:
        {
            /* check SW2 & reset request flag */
            u1_temp_sw_signal = get_sw2();
            if ((SW_OFF == g_u1_reset_req) && (MTR_FLG_SET == mtr_remove_sw_chattering(u1_temp_sw_signal, SW2_ON)))
            {
                g_u1_reset_req = SW_ON;
            }
            else if ((SW_ON == g_u1_reset_req) && (MTR_FLG_SET == mtr_remove_sw_chattering(u1_temp_sw_signal, SW2_OFF)))
            {
                g_u1_reset_req = SW_OFF;
                g_motor0_control.p_api->reset(g_motor0_control.p_ctrl);
            }
            else
            {
                /* Do nothing */
            }

            break;
        }

        default:                       /* Do nothing */
        {
            break;
        }
    }

    /*=============================*/
    /*      Set speed reference    */
    /*=============================*/
#ifndef MOTOR_CONTROL_TRAJECTORY_ENABLED
    g_f4_speed_ref = ((float) g_u2_vr1_ad - ADJUST_OFFSET) * VR1_SCALING; /* Read speed reference from VR1 */
    g_motor0_control.p_api->speedSet(g_motor0_control.p_ctrl, g_f4_speed_ref);

    if ((g_f4_speed_ref > (-STOP_RPM)) && (g_f4_speed_ref < STOP_RPM))    /* Check SW1 */
    {
        g_u1_stop_req = MTR_FLG_SET;
    }
    else
    {
        g_u1_stop_req = MTR_FLG_CLR;
    }
#endif

    /***** LED control *****/
    mtr_board_led_control(g_u1_motor_status);
}                                      /* End of function board_ui */

/***********************************************************************************************************************
 * Function Name : ics_ui
 * Description   : User interface using ICS
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void ics_ui (void)
{
    uint8_t u1_temp;

    mtr_set_com_variables();

    /*============================*/
    /*        Execute event       */
    /*============================*/
    u1_temp = com_u1_mode_system;

    if (g_u1_mode_system != u1_temp)
    {
        if (u1_temp > MOTOR_CONTROL_EVENT_RESET)
        {
            com_u1_mode_system = g_u1_mode_system;
        }
        else
        {
            g_u1_mode_system = u1_temp;
            switch (g_u1_mode_system)
            {
                case MOTOR_CONTROL_EVENT_STOP:
                {
                    g_motor0_control.p_api->stop(g_motor0_control.p_ctrl);
                    break;
                }

                case MOTOR_CONTROL_EVENT_RUN:
                {
                    g_motor0_control.p_api->run(g_motor0_control.p_ctrl);
                    break;
                }

                case MOTOR_CONTROL_EVENT_RESET:
                {
                    g_motor0_control.p_api->reset(g_motor0_control.p_ctrl);
                    break;
                }

                default:
                {
                    /* Do nothing */
                    break;
                }
            }
        }
    }

    g_motor0_control.p_api->statusGet(g_motor0_control.p_ctrl, &g_u1_motor_status);

    if (MOTOR_CONTROL_EVENT_RESET == g_u1_mode_system)
    {
        if (MOTOR_CONTROL_STATUS_STOP == g_u1_motor_status)
        {
            software_init();           /* Initialize private global variables for reset event */
        }
        else if (MOTOR_CONTROL_STATUS_ERROR == g_u1_motor_status)
        {
            g_u1_mode_system   = MOTOR_CONTROL_EVENT_ERROR;
            com_u1_mode_system = MOTOR_CONTROL_EVENT_ERROR;
        }
        else
        {
            /* Do nothing */
        }
    }

    /***** LED control *****/
    mtr_board_led_control(g_u1_motor_status);
}                                      /* End of function ics_ui */

/***********************************************************************************************************************
 * Function Name : software_init
 * Description   : Initialize private global variables
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void software_init (void)
{
    g_u1_motor_status  = MOTOR_CONTROL_STATUS_STOP;
    g_u2_max_speed_rpm = MTR_MAX_SPEED_RPM;
    g_u1_sw_userif     = CONFIG_DEFAULT_UI;
    g_u1_mode_system   = MOTOR_CONTROL_EVENT_STOP;
    g_u1_reset_req     = SW_OFF;
    g_u2_chk_error     = MOTOR_ERROR_NONE;

    /* ICS variables initialization */
    com_u1_sw_userif   = CONFIG_DEFAULT_UI;
    com_u1_mode_system = MOTOR_CONTROL_EVENT_STOP;
    mtr_ics_variables_init();
    mtr_set_com_variables();
}                                      /* End of function software_init */

/***********************************************************************************************************************
 * Function Name : g_poe_overcurrent
 * Description   : POEG2 Interrupt callback function
 * Arguments     : p_args - Callback argument
 * Return Value  : None
 ***********************************************************************************************************************/
void g_poe_overcurrent (poeg_callback_args_t * p_args)
{
    if (NULL != p_args)
    {
        R_POEG_Reset(g_poeg0.p_ctrl);
        g_motor0_control.p_api->errorSet(g_motor0_control.p_ctrl, MOTOR_ERROR_OVER_CURRENT_HW);
        g_u2_chk_error |= MOTOR_ERROR_OVER_CURRENT_HW;
    }
}                                      /* End of function g_poe_overcurrent */

/***********************************************************************************************************************
 * Function Name : motor_fsp_init
 * Description   : Initialize Motor FSP modules
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void motor_fsp_init (void)
{
    R_POEG_Open(g_poeg0.p_ctrl, g_poeg0.p_cfg);
    g_elc.p_api->open(g_elc.p_ctrl, g_elc.p_cfg);
    g_elc.p_api->enable(g_elc.p_ctrl);

    // Sensor 1 BEMF sensor support
#if(MOTOR_SENSOR_1 == 1)
    g_user_motor_sensor_cfg            = *(g_motor0_sensor_bemf.p_cfg);
    g_user_motor_estimate_extended_cfg = *(motor_sensor_bemf_extended_cfg_t *) g_user_motor_sensor_cfg.p_extend;
    g_user_motor_sensor_cfg.p_extend   = &g_user_motor_estimate_extended_cfg;
#endif

    // Sensor 1 Hall sensor support
#if(MOTOR_SENSOR_1 == 2)
    g_user_motor_sensor_cfg               = *(g_motor0_sensor_hall.p_cfg);
    g_user_motor_sensor_hall_extended_cfg = *(motor_sensor_hall_extended_cfg_t *) g_user_motor_sensor_cfg.p_extend;
    g_user_motor_sensor_cfg.p_extend      = &g_user_motor_sensor_hall_extended_cfg;
#endif

    //Sensor 2 Hall sensor support
#if(MOTOR_SENSOR_2 == 1)
    g_user_motor_sensor_cfg_2nd           = *(g_motor0_sensor_hall.p_cfg);
    g_user_motor_sensor_hall_extended_cfg = *(motor_sensor_hall_extended_cfg_t *) g_user_motor_sensor_cfg_2nd.p_extend;
    g_user_motor_sensor_cfg_2nd.p_extend  = &g_user_motor_sensor_hall_extended_cfg;
#endif

    g_user_motor_hal_driver_cfg          = *(g_motor0_hal_driver.p_cfg);
    g_user_motor_hal_driver_extended_cfg = *(motor_hal_driver_extended_cfg_t *) g_user_motor_hal_driver_cfg.p_extend;
    g_user_motor_hal_driver_cfg.p_extend = &g_user_motor_hal_driver_extended_cfg;

    g_user_motor_pm_foc_cfg          = *(g_motor0_pm_foc.p_cfg);
    g_user_motor_pm_foc_extended_cfg = *(motor_pm_foc_extended_cfg_t *) g_user_motor_pm_foc_cfg.p_extend;
    g_user_motor_pm_foc_cfg.p_extend = &g_user_motor_pm_foc_extended_cfg;

    g_user_motor_cfg = g_motor0_control_cfg;
    RM_MOTOR_CONTROL_Open(&g_motor0_control_ctrl, &g_user_motor_cfg);
}                                      /* End of function motor_fsp_init */

/***********************************************************************************************************************
 * Function Name : mtr_callback_event
 * Description   : Initialize Motor FSP modules
 * Arguments     : p_args - Callback argument
 * Return Value  : None
 ***********************************************************************************************************************/
void mtr_callback_event (motor_callback_args_t * p_args)
{
    switch (p_args->event)
    {
        case MOTOR_CALLBACK_EVENT_SPEED_BACKWARD:
        {
            g_u2_vr1_ad = get_vr1();
            break;
        }

        case MOTOR_CALLBACK_EVENT_CURRENT_BACKWARD:
        {
            mtr_ics_interrupt_process();
            break;
        }

        case MOTOR_CALLBACK_EVENT_ERROR:
        {
            if (MOTOR_CONTROL_STATUS_ERROR != g_u1_motor_status)
            {
                g_motor0_control.p_api->errorCheck(g_motor0_control.p_ctrl, &g_u2_chk_error);
            }

            break;
        }

        default:
        {
            break;
        }
    }
}                                      /* End of function mtr_callback_event */

/***********************************************************************************************************************
 * Function Name : mtr_board_led_control
 * Description   : Set LED pattern depend on motor status
 * Arguments     : u1_motor_status - Motor control status
 * Return Value  : None
 ***********************************************************************************************************************/
static void mtr_board_led_control (uint8_t u1_motor_status)
{
    /***** LED control *****/
    if (MOTOR_CONTROL_STATUS_STOP == u1_motor_status)       /* Check motor status */
    {
        led1_off();                                         /* LED1 off */
        led2_off();                                         /* LED2 off */
        led3_off();                                         /* LED3 off */
    }
    else if (MOTOR_CONTROL_STATUS_RUN == u1_motor_status)   /* Check motor status */
    {
        led1_on();                                          /* LED1 on */
        led2_off();                                         /* LED2 off */
    }
    else if (MOTOR_CONTROL_STATUS_ERROR == u1_motor_status) /* Check motor status */
    {
        led1_off();                                         /* LED1 off */
        led2_on();                                          /* LED2 on */
        led3_off();                                         /* LED3 off */
    }
    else
    {
        led1_on();                                          /* LED1 on */
        led2_on();                                          /* LED2 on */
        led3_on();                                          /* LED3 on */
    }
} /* End of function mtr_board_led_control */

/***********************************************************************************************************************
 * Function Name : mtr_remove_sw_chattering
 * Description   : Get switch status with removing chattering
 * Arguments     : u1_sw - Board interface switch signal
 *                 u1_on_off - Detected status (ON/OFF)
 * Return Value  : u1_remove_chattering_flg - Detection result
 ***********************************************************************************************************************/
static uint8_t mtr_remove_sw_chattering (uint8_t u1_sw, uint8_t u1_on_off)
{
    uint8_t u1_remove_chattering_flg;

    u1_remove_chattering_flg = 0;
    if (u1_on_off == u1_sw)
    {
        g_u1_sw_cnt++;
        if (CHATTERING_CNT < g_u1_sw_cnt)
        {
            u1_remove_chattering_flg = MTR_FLG_SET;
            g_u1_sw_cnt              = 0;
        }
    }
    else
    {
        g_u1_sw_cnt = 0;
    }

    return u1_remove_chattering_flg;
}                                      /* End of function mtr_remove_sw_chattering */

/***********************************************************************************************************************
 * Function Name : get_vr1
 * Description   : Get A/D converted value of VR1
 * Arguments     : None
 * Return Value  : A/D converted value of VR1
 ***********************************************************************************************************************/
static uint16_t get_vr1 (void)
{
    uint16_t ad_data;

    g_adc0.p_api->read(g_adc0.p_ctrl, MTR_ADCH_VR1, &ad_data);

    return ad_data;
}                                      /* End of function get_vr1 */

/***********************************************************************************************************************
 * Function Name : get_sw1
 * Description   : Get state of SW1
 * Arguments     : None
 * Return Value  : State of SW1
 ***********************************************************************************************************************/
static uint8_t get_sw1 (void)
{
    bsp_io_level_t tmp_port;

    R_IOPORT_PinRead(&g_ioport_ctrl, MTR_PORT_SW1, &tmp_port);

    return (uint8_t) tmp_port;
}                                      /* End of function get_sw1 */

/***********************************************************************************************************************
 * Function Name : get_sw2
 * Description   : Get state of SW2
 * Arguments     : None
 * Return Value  : State of SW2
 ***********************************************************************************************************************/
static uint8_t get_sw2 (void)
{
    bsp_io_level_t tmp_port;

    R_IOPORT_PinRead(&g_ioport_ctrl, MTR_PORT_SW2, &tmp_port);

    return (uint8_t) tmp_port;
}                                      /* End of function get_sw2 */

/***********************************************************************************************************************
 * Function Name : led1_on
 * Description   : Turn on LED1
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void led1_on (void)
{
    R_IOPORT_PinWrite(&g_ioport_ctrl, MTR_PORT_LED1, MTR_LED_ON);
}                                      /* End of function led1_on */

/***********************************************************************************************************************
 * Function Name : led2_on
 * Description   : Turn on LED2
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void led2_on (void)
{
    R_IOPORT_PinWrite(&g_ioport_ctrl, MTR_PORT_LED2, MTR_LED_ON);
}                                      /* End of function led2_on */

/***********************************************************************************************************************
 * Function Name : led3_on
 * Description   : Turn on LED3
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void led3_on (void)
{
    // LED3 is not assigned on MCB-RA6T3/RA4T1.
    // Do nothing.
}                                      /* End of function led3_on */

/***********************************************************************************************************************
 * Function Name : led1_off
 * Description   : Turn off LED1
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void led1_off (void)
{
    R_IOPORT_PinWrite(&g_ioport_ctrl, MTR_PORT_LED1, MTR_LED_OFF);
}                                      /* End of function led1_off */

/***********************************************************************************************************************
 * Function Name : led2_off
 * Description   : Turn off LED2
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void led2_off (void)
{
    R_IOPORT_PinWrite(&g_ioport_ctrl, MTR_PORT_LED2, MTR_LED_OFF);
}                                      /* End of function led2_off */

/***********************************************************************************************************************
 * Function Name : led3_off
 * Description   : Turn off LED3
 * Arguments     : None
 * Return Value  : None
 ***********************************************************************************************************************/
static void led3_off (void)
{
    // LED3 is not assigned on MCB-RA6T3/RA4T1.
    // Do nothing.
}                                      /* End of function led3_off */
